
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import javax.sound.sampled.Line;

public class DVDStoreApp {

	public static List<List<String>> Loans = new ArrayList<>();
	
	public static List<LOANS> addLoans = new ArrayList<>();
	
	public static List<DVD> addDVD = new ArrayList<>();
	
	public static List<USERS> addUsers = new ArrayList<>();
	
	public static void main(String[] args) {
	
		readDVD(); 
		readUsers();
		readLoans(); 
		
		lanchMenu(); 
		
	}
	
	private static void lanchMenu() {
		System.out.println("1 Issue an DVD"); 
		System.out.println("2 Return loaned DVD"); 
		System.out.println("3 view active DVD loans"); 
		
		Scanner sc = new Scanner(System.in); 
		
		System.out.print("Choice: ");
		String choice = sc.next(); 
		
		switch (choice) {
		
		
		case "1": 
			issueLoan(); 
			break; 
		case "2": 
		returnDVD(); 
			break; 
		case "3": 
			loanedDVD();  
			break; 
		default: 
			System.out.println("Incorrect Input"); 
			System.out.println(""); 
			lanchMenu();
		}
		
		sc.close();
		
		
	}
	
	private static DVD[] getAllDVD() {
		
		DVD[] l = new DVD[addDVD.size()]; 
		
		if (addDVD.size() > 0) {
			
			for (int index = 0; index < addDVD.size(); index++ ) {			
				l[index] = addDVD.get(index); 
			}
			
			return l;
		}
		return null;
	}
	


	public static void readDVD() {
		
		try(BufferedReader br = new BufferedReader(new FileReader("DVD.csv"))) {
			String line; 
				
				while((line = br.readLine()) != null) {
					String[] values = line.split((",")); 
					DVD dvd = new DVD(); 
					
					dvd.setDVDCode(values[0]);
					dvd.setTitle(values[1]);
					addDVD.add(dvd); 
					
				}
				
				DVD l[] = getAllDVD();
				
				for  (int  index1 = 0; index1 < l.length; index1++) {
					
					System.out.println("[" + l[index1].getDVDCode() + ", " + l[index1].getTitle() + "]");
				}
		}
		
		catch (FileNotFoundException e) {
			e.printStackTrace(); 
		}
		
		catch (IOException e) {
			e.printStackTrace(); 
		}
		
		System.out.println("");;
		
	}
	

	
	private static USERS[] getAllUsers() {
		
		USERS[] l = new USERS[addUsers.size()]; 
		
		if (addUsers.size() > 0) {
			for (int index = 0; index < addUsers.size(); index++) {
				l[index] = addUsers.get(index);
			}
			
			return l ;
		}
		
		return null;
		
	}
	
	
	public static void readUsers() {
		try (BufferedReader br = new BufferedReader(new FileReader("USERS.csv"))) {
			String line; 
			
			while ((line = br.readLine()) != null) {
				
				String[] values = line.split(",");
				USERS u = new USERS(); 
				
			u.setUserCode(values[0]); 
			u.setName((values[1]));
			addUsers.add(u); 
			}
			
			USERS u1[] = getAllUsers(); 
			
			for (int index1 = 0; index1 < u1.length; index1++) {
				System.out.println("[" +  u1[index1].getUserCode() + ", " + u1[index1].getName() + "]");
			}
			
			
		}
		catch (FileNotFoundException e) {
			e.printStackTrace(); 
		}
		
		catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(""); 
	}
	
	
	private static LOANS[] getAllLoans() {
		
		LOANS [] l = new LOANS[addLoans.size()]; 
		
		if (addLoans.size() > 0) {
			
			for (int index = 0; index < addLoans.size(); index++) {
				l[index] =addLoans.get(index); 
			}
			
			return l; 
			
		}
		
		return null; 
		
	}
	
	public static void readLoans() {
		try (BufferedReader br = new BufferedReader(new FileReader("LOANS.csv"))) {
			
			String line; 
			while ((line = br.readLine()) != null) 
			{
				String[] values = line.split(","); 
				LOANS u = new LOANS();
				
				u.setDVD((values[0]));
				u.setUser(values[1]);
				u.settDueDate(values[2]);
				u.setLoanDate(values[3]);
				u.setReleases(values[4]);
				
				addLoans.add(u); 
				
			}
			
			LOANS u1[] = getAllLoans(); 
			
			for (int index1 = 0; index1 < u1.length; index1++) {
				System.out.println("[" + u1[index1].getDVD() + ", " + u1[index1].getUser() + ", " + u1[index1].getDueDate() + ", " + u1[index1].getLoanDate() + ", " +  u1[index1].getRelease() + "]"); 
			}
			
		}
		
		catch   (FileNotFoundException e) {
			e.printStackTrace(); 
		}
		
		catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("");
	}

	public static LOANS searchDVD(String bar ) {
		
		for (int index = 0; index < addLoans.size(); index++ ) {
			
			LOANS barC = addLoans.get(index); 
			String thisBarC = barC.getDVD(); 
			
				if (thisBarC.equals(bar))  {
					return barC; 
				}
			
		}
		
		return null; 
		
	}
	
	public static LOANS searchUser(String bar) {
		
		for (int index = 0;  index < addLoans.size(); index++) {
			LOANS barC = addLoans.get(index);
				String thisBarC = barC.getUser(); 
				if (thisBarC.equals(bar)) {
					return barC;
				}
				
			
		}
		return null; 
		
	}
	
	private static void issueLoan() {
		
		LocalDateTime date = LocalDateTime.now(); 
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy"); 
		
		String currentDate = date.format(format); 
		
		Scanner input = new Scanner(System.in); 
		
		System.out.println("Please enter in the DVD code");
		System.out.print("Input"); 
		String bar = input.nextLine(); 
		
		if (searchDVD(bar) != null) {
			System.out.println(""); 
			System.out.println("DVD is alreadly issueed please select another one");
			System.out.println(""); 
			issueLoan(); 
		}
		
		else {
			String code = ""; 
			switch (bar) {
			case "1": 
				code = "Jurassic World Dominion"; 
				break; 
			case "2": 
				code = "Elvis"; 
				break; 
			case "3": 
				code = "Top Gun: Maverick"; 
				break; 
			default: 
				System.out.println("Invalid Data input"); 
				System.out.println("");
				issueLoan(); 
				break;
			}
			
			System.out.println(""); 
			System.out.println("Please enter in the UserID"); 
			System.out.print("Input: "); 
			String user = input.nextLine(); 
			String username = "";
			
			switch(user) {
			case "a": 
				username = "Ryan Donnelly"; 
			break; 
			case "b":
				username = "Bailey O' Neil"; 
			break; 
			
			case "c": 
				username = "David Auren"; 
				break; 
			default: 
				System.out.println("Invalid Dat input"); 
				System.out.println(""); 
				issueLoan(); 
				break; 
			}
			
			LocalDate date1; 
			int  days = 0; 
			int renew = 1; 
			
			date1 = LocalDate.now().plusDays(days); 
			String dvdCode = date.format(format);
			
			LOANS loan = new LOANS(bar, user, currentDate, dvdCode, renew); 
			USERS users = new USERS(username);
			DVD d = new DVD(code); 
			addLoans.add(loan); 
			
			System.out.println("Loan added" + ", " + d.getTitle() + ", " + users.getName() + ", " + loan.getLoanDate() + ", " + loan.getDueDate() +  ", " + loan.getRelease2()); 
			System.out.println("");
			lanchMenu();
			
		}

	}
	
	private static void returnDVD() {
		System.out.println(""); 
		
		LOANS l = null; 
		
		for (int i = 0; i < addLoans.size(); i++) {
			l = addLoans.get(i); 
			
			System.out.println("[" + l.getDVD() + " " + l.getUser() +  " " + l.getLoanDate() + " " + l.getDueDate() + "]");
			
		}
		
		String barcode; 
		Scanner sc  = new Scanner(System.in); 
		
		System.out.print("DVD Code: ");
		barcode = sc.next(); 
		
		if (searchDVD(barcode ) != null) {
			System.out.println("");
			System.out.println("DVD Removed"); 
			addLoans.remove((l)); 
			System.out.println(""); 
			lanchMenu(); 
		}
		
		else {
			System.out.println("DVD code not found"); 
			returnDVD(); 
		}
		System.out.println(""); 
		
	}
	
	private static void loanedDVD() {
	System.out.println(""); 
		
		LOANS l = null; 
		
		for (int i = 0; i < addLoans.size(); i++) {
			l = addLoans.get(i); 
			
			System.out.println("[" + l.getDVD() + " " + l.getUser() +  " " + l.getLoanDate() + " " + l.getDueDate() + "]");
			
		}
		
		System.out.println(""); 
		lanchMenu(); 
		
		
	}
	
	
		
	}


