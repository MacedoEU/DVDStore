
public class DVD {

	private String DVD_Code; 
	private String title; 
	
	public DVD() {
		
	}
	
	public DVD(String code) {
		this.title = code;
	}
	
	public String getDVDCode() {
		return this.DVD_Code;
	}
	
	public String getTitle() {
		return this.title;
	}
	
	public void setDVDCode(String DVDCode) {
		this.DVD_Code = DVDCode;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	
	
}
