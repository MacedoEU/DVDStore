
public class LOANS {

	private String DVD; 
	private String user;
	private String loanDate; 
	private String dueDate; 
	private String numberOfReleases; 
	
	private static int releasesI; 
	
	public LOANS() {
		
	}
	
	public LOANS(String DVD, String user, String loanDate, String dueDate, String numberOfReleases) {
		this.DVD = DVD; 
		this.user = user; 
		this.loanDate = loanDate; 
		this.dueDate = dueDate; 
		this.numberOfReleases = numberOfReleases;
	}

	public LOANS(String DVD, String user, String loanDate, String dueDate, int numberOfReleases) {
		this.DVD = DVD; 
		this.user = user; 
		this.loanDate = loanDate; 
		this.dueDate = dueDate; 
		this.releasesI = numberOfReleases;
	}
	
	public String getDVD() {
		return this.DVD; 
	}
	
	public String getUser() {
		return this.user; 
	}
	
	public String getLoanDate() {
		return this.loanDate; 
	}
	
	public String getDueDate() {
		return this.dueDate; 
	}
	
	public String getRelease() {
		return this.numberOfReleases;
	}
	
	public int getRelease2()
	{
		return this.releasesI;
	}
	
	public void setDVD(String dvd) {
		this.DVD = dvd;
	}
	
	public void setUser(String user) {
		this.user = user;
	}
	
	public void setLoanDate(String loanDate) {
		this.loanDate = loanDate;
	}
	
	public void settDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	public void setReleases(String r) {
		this.numberOfReleases = r;
	}
	
	public void setReleasesI(int r) {
		this.releasesI = r;
	}
}
