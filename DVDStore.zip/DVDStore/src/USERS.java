
public class USERS {

	private String userCode; 
	private String name; 
	
	public USERS() {
		
	}
	
	public USERS(String username) {
		this.name = username;
	}
	
	public String getUserCode() {
		return this.userCode;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setUserCode(String code) {
		this.userCode = code;
	}
	
	public void setName(String name ) {
		this.name = name;
	}
	
	
}
